#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Feb 21 06:58:00 2019

@author: daniel
"""

import pandas as pd
import numpy as np
import flask as flask
from sklearn import linear_model
from sklearn.metrics import r2_score
regr=linear_model.LinearRegression()

app = Flask(__name__)


datos=pd.read_csv('movies.csv')
df=pd.DataFrame(datos)
x=df['movie_facebook_likes']
y=df['imdb_score']

X=x[:,np.newaxis]
print(X)
print(regr.fit(X,y))
print(regr.coef_)
m=regr.coef_[0]
b=regr.intercept_
y_p=m*X+b
print('y={0}*x+{1}'.format(m,b))
print(regr.predict(X)[0:5])
print('el valor de r^2: ', r2_score(y,y_p))


@app.route('/')
def x():
    return X

if __name__ =='__main__':
app.run('0.0.0.0', 5000, debug=True)




